const fetch = require('node-fetch');
require('dotenv').config(); // Load environment variables from a .env file

// OpenAI API endpoint and key
const OPENAI_API_URL = 'https://api.openai.com/v1/completions';
const API_KEY = process.env.OPENAI_API_KEY;

if (!API_KEY) {
  throw new Error('OPENAI_API_KEY is not set in the environment variables.');
}

// GPT-3 Class
class GPT3Model {
  constructor() {
    this.defaultOptions = {
      model: 'text-davinci-003', // Change this to 'gpt-4' if needed and available
      max_tokens: 150,
      temperature: 0.7,
      top_p: 1.0,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
    };
  }

  /**
   * Send a prompt to GPT-3 and get the response
   * @param {string} prompt - The user input or query
   * @param {object} options - Additional options for GPT-3
   * @returns {Promise<string>} - The GPT-3 response
   */
  async processPrompt(prompt, options = {}) {
    // Merge default options with custom options
    const requestData = { ...this.defaultOptions, prompt, ...options };

    try {
      // Make the API request
      const response = await fetch(OPENAI_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${API_KEY}`,
        },
        body: JSON.stringify(requestData),
      });

      if (!response.ok) {
        const errorDetails = await response.text();
        throw new Error(
          `OpenAI API request failed with status ${response.status}: ${errorDetails}`
        );
      }

      // Parse the response
      const data = await response.json();

      // Return the generated text
      return data.choices && data.choices[0] ? data.choices[0].text.trim() : null;
    } catch (error) {
      console.error('Error processing prompt with OpenAI API:', error);
      throw error;
    }
  }
}

// Usage Example
(async () => {
  const gpt3 = new GPT3Model();
  const userPrompt = 'Explain quantum mechanics in simple terms.';

  try {
    const response = await gpt3.processPrompt(userPrompt, { max_tokens: 200 });
    console.log('GPT-3 Response:', response);
  } catch (error) {
    console.error('Error:', error.message);
  }
})();

// Export the GPT-3 Model
module.exports = GPT3Model;
