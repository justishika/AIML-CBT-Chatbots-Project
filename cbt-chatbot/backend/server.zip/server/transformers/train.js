const tf = require('@tensorflow/tfjs');
require('@tensorflow/tfjs-node'); // TensorFlow.js for Node.js
const fs = require('fs').promises; // For reading the JSON file

async function loadDataset(filePath) {
  try {
    const data = await fs.readFile(filePath, 'utf-8');
    const jsonData = JSON.parse(data);

    // Split features and labels
    const inputs = jsonData.map(item => item.features); // Assuming "features" is an array
    const labels = jsonData.map(item => item.label);    // Assuming "label" is a scalar

    return { inputs, labels };
  } catch (error) {
    console.error('Error reading or parsing the dataset:', error);
    throw error;
  }
}

async function trainModel(datasetPath) {
  // Load the dataset
  const { inputs, labels } = await loadDataset(datasetPath);

  // Convert inputs and labels to tensors
  const inputTensor = tf.tensor2d(inputs); // 2D tensor for features
  const labelTensor = tf.tensor2d(labels, [labels.length, 1]); // Convert labels to a column vector

  // Build the model
  const model = tf.sequential();

  model.add(tf.layers.dense({
    units: 32,             // Hidden layer with 32 neurons
    activation: 'relu',    // ReLU activation for non-linearity
    inputShape: [inputs[0].length], // Input shape based on feature size
  }));

  model.add(tf.layers.dense({
    units: 16,
    activation: 'relu',
  }));

  model.add(tf.layers.dense({
    units: 1,              // Output layer with 1 neuron (regression task)
    activation: 'linear',  // Linear activation for continuous output
  }));

  // Compile the model
  model.compile({
    optimizer: tf.train.adam(0.01), // Adam optimizer with learning rate 0.01
    loss: 'meanSquaredError',      // Loss function for regression
    metrics: ['mae'],              // Track mean absolute error
  });

  console.log('Starting training...');

  // Train the model
  await model.fit(inputTensor, labelTensor, {
    epochs: 50,                  // Train for 50 epochs
    batchSize: 32,               // Process data in batches of 32
    validationSplit: 0.2,        // Use 20% of data for validation
    verbose: 1,                  // Display progress
    callbacks: tf.callbacks.earlyStopping({ // Early stopping to prevent overfitting
      monitor: 'val_loss',
      patience: 5,
    }),
  });

  console.log('Training completed!');

  // Save the trained model
  const savePath = './model';
  await model.save(`file://${savePath}`);
  console.log(`Model saved to ${savePath}`);
}

// Run the training
trainModel('./data/set.json').catch(error => {
  console.error('Error during training:', error);
});
