const analyzeHandler = require('../handlers/analyzeHandler');
const { mockRequest, mockResponse } = require('./testUtils'); // Utility functions for mock req/res
const { processPrompt } = require('../services/openaiService');

jest.mock('../services/openaiService'); // Mock the OpenAI service

describe('analyzeHandler', () => {
  afterEach(() => {
    jest.clearAllMocks(); // Clear mocks after each test
  });

  it('should return a successful response when the input is valid', async () => {
    // Arrange
    const mockReq = mockRequest({
      body: { input: 'What is quantum computing?' },
    });
    const mockRes = mockResponse();

    const mockOpenAIResponse = 'Quantum computing is a type of computing that uses qubits.';
    processPrompt.mockResolvedValue(mockOpenAIResponse);

    // Act
    await analyzeHandler(mockReq, mockRes);

    // Assert
    expect(processPrompt).toHaveBeenCalledTimes(1);
    expect(processPrompt).toHaveBeenCalledWith('What is quantum computing?');
    expect(mockRes.status).toHaveBeenCalledWith(200);
    expect(mockRes.json).toHaveBeenCalledWith({ success: true, output: mockOpenAIResponse });
  });

  it('should return a 400 error when input is missing', async () => {
    // Arrange
    const mockReq = mockRequest({ body: {} });
    const mockRes = mockResponse();

    // Act
    await analyzeHandler(mockReq, mockRes);

    // Assert
    expect(processPrompt).not.toHaveBeenCalled();
    expect(mockRes.status).toHaveBeenCalledWith(400);
    expect(mockRes.json).toHaveBeenCalledWith({
      success: false,
      error: 'Input is required.',
    });
  });

  it('should return a 500 error when OpenAI service fails', async () => {
    // Arrange
    const mockReq = mockRequest({
      body: { input: 'Explain AI ethics.' },
    });
    const mockRes = mockResponse();

    const mockError = new Error('OpenAI API error');
    processPrompt.mockRejectedValue(mockError);

    // Act
    await analyzeHandler(mockReq, mockRes);

    // Assert
    expect(processPrompt).toHaveBeenCalledTimes(1);
    expect(processPrompt).toHaveBeenCalledWith('Explain AI ethics.');
    expect(mockRes.status).toHaveBeenCalledWith(500);
    expect(mockRes.json).toHaveBeenCalledWith({
      success: false,
      error: 'Internal server error.',
    });
  });
});
